# GitHub Pages upload instructions

Upload `index.html` and the `images` folder to the root of your GitHub repository.

Then open **Settings → Pages** in the repository and set:

- **Source:** Deploy from a branch
- **Branch:** main
- **Folder:** / (root)

Save the settings. GitHub will publish the site at a URL like:
`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`
